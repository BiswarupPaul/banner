/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
export default {"kk":{"dictionary":{"Align left":"Солға туралау","Align right":"Оңға туралау","Align center":"Ортадан туралау","Justify":"","Text alignment":"Мәтінді туралау","Text alignment toolbar":"Мәтінді туралау құралдар тақтасы"},getPluralForm(n){return (n!=1);}}}